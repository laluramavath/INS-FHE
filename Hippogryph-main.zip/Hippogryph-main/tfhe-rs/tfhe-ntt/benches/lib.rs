#![allow(dead_code)]

mod ntt;
