#![allow(warnings)]
pub type c_void = std::ffi::c_void;
pub type c_uint = std::ffi::c_uint;
pub type c_uchar = std::ffi::c_uchar;
pub type c_ushort = std::ffi::c_ushort;
pub type c_ulong = std::ffi::c_ulong;
pub type c_schar = std::ffi::c_schar;
pub type c_int = std::ffi::c_int;
pub type c_short = std::ffi::c_short;
pub type c_long = std::ffi::c_long;
pub type c_char = std::ffi::c_char;
