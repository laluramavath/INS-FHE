# Contributing

There are two ways to contribute to `TFHE-rs`. You can:

* open issues to report bugs and typos and to suggest ideas;
* ask to become an official contributor by emailing hello@zama.ai. Only approved contributors can send pull requests, so get in touch before you do.
