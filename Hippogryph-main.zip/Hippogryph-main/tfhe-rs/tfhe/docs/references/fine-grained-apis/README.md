# Fine-grained APIs

* [Quick start](quick\_start.md)
* [Boolean](boolean/)
* [Shortint](shortint/)
* [Integer](integer/)
