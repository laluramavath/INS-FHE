use aes::demo_aes;

mod aes;
fn main() {
    demo_aes();
}
